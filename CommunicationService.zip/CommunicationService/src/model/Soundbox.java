package model;

public class Soundbox extends Request{
}
