package model;

public class Email extends Request{

    String subject;

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    @Override
    public String toString() {
        return String.format(
                "{\"senderId\": \"%s\", \"receiverId\": \"%s\", \"message\": \"%s\", \"subject\": \"%s\"}",
                senderId, receiverId, message, subject
        );
    }
}
