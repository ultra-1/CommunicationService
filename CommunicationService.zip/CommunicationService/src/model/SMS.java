package model;

public class SMS extends Request{
}
