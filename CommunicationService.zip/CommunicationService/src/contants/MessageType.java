package contants;

public enum MessageType {
    SMS, EMAIL, SOUNDBOX
}
